"""Per-page text extraction with pypdf (P026 T003).

One :class:`PageTextRecord` is produced for every physical page —
indices are continuous from 0, no page is ever silently skipped.
A page that fails to extract is recorded with ``text_state="ERROR"``
(``extracted_text`` and ``text_sha256`` are ``None``) instead of being
dropped.

Text states (PROJECT_BOOK.md §4.3, stage Extraction):

* ``TEXT`` — pypdf returned non-blank text.
* ``EMPTY`` — no text layer content and no embedded images (a genuinely
  blank page).
* ``IMAGE_ONLY`` — no text layer content, but the page embeds at least
  one image (a scanned / raster page). No OCR is ever started: the
  visible raster text is *not* recoverable from the text layer and the
  record honestly says so.
* ``ERROR`` — ``extract_text()`` raised; the page could not be read.

``text_sha256`` is the SHA-256 of the §4.2-normalised extracted text
(see :mod:`pagetrace.normalize`), which is exactly how the T002
fixture bundles compute their extraction ``text_sha256`` values; it is
``None`` for ``EMPTY`` / ``IMAGE_ONLY`` / ``ERROR`` pages (there is no
extracted text to hash — ``None`` means "no text", not "empty text").
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from pypdf import PdfReader

from .normalize import sha256_hex_of_normalized
from .pdf_input import PdfDocumentInfo, PdfInputError, load_pdf

TextState = Literal["TEXT", "EMPTY", "IMAGE_ONLY", "ERROR"]


@dataclass(frozen=True)
class PageTextRecord:
    """Extraction result for one physical PDF page.

    ``pdf_page_index0`` is the canonical page identity (0-based).
    ``pdf_page_label`` is the PDF page label, or ``None`` when the PDF
    defines no label for the page. ``extracted_text`` is the raw text
    exactly as pypdf returned it (``""`` for ``EMPTY``/``IMAGE_ONLY``,
    ``None`` only when extraction raised). ``text_sha256`` is the
    SHA-256 of the normalised extracted text for ``TEXT`` pages and
    ``None`` otherwise.
    """

    pdf_page_index0: int
    pdf_page_label: str | None
    text_state: TextState
    text_sha256: str | None
    extracted_text: str | None


def _page_has_images(page) -> bool:
    """True if the page embeds at least one image.

    Image enumeration itself can fail on malformed pages; a failure
    here is treated as "no images found" (the page is then honestly
    reported ``EMPTY`` — no text was found either way) rather than
    failing the whole document.
    """
    try:
        return len(page.images) > 0
    except Exception:
        return False


def _extract_one_page(page, pdf_page_index0: int,
                      pdf_page_label: str | None) -> PageTextRecord:
    try:
        raw = page.extract_text()
    except Exception:
        return PageTextRecord(
            pdf_page_index0=pdf_page_index0,
            pdf_page_label=pdf_page_label,
            text_state="ERROR",
            text_sha256=None,
            extracted_text=None,
        )
    if raw is None or raw.strip() == "":
        state: TextState = (
            "IMAGE_ONLY" if _page_has_images(page) else "EMPTY")
        return PageTextRecord(
            pdf_page_index0=pdf_page_index0,
            pdf_page_label=pdf_page_label,
            text_state=state,
            text_sha256=None,
            extracted_text="",
        )
    return PageTextRecord(
        pdf_page_index0=pdf_page_index0,
        pdf_page_label=pdf_page_label,
        text_state="TEXT",
        text_sha256=sha256_hex_of_normalized(raw),
        extracted_text=raw,
    )


def extract_pages(info: PdfDocumentInfo) -> list[PageTextRecord]:
    """Extract every page of a validated document.

    Returns exactly ``info.page_count`` records, in physical order,
    with indices 0..``page_count - 1``. Raises :class:`PdfInputError`
    (``CORRUPT``) if the file on disk no longer matches the validated
    info (page count changed between validation and extraction).
    """
    try:
        reader = PdfReader(info.file_path)
        page_count = len(reader.pages)
    except PdfInputError:
        raise
    except Exception as exc:
        raise PdfInputError(
            "CORRUPT", f"PDF cannot be re-opened for extraction: {exc}",
            info.file_path) from exc
    if page_count != info.page_count:
        raise PdfInputError(
            "CORRUPT",
            f"PDF page count changed between validation "
            f"({info.page_count}) and extraction ({page_count})",
            info.file_path)
    labels = info.page_labels
    return [
        _extract_one_page(page, index,
                          labels[index] if index < len(labels) else None)
        for index, page in enumerate(reader.pages)
    ]


def extract_pdf(
    path: str,
    *,
    max_file_size_bytes: int | None = None,
    max_pages: int | None = None,
) -> tuple[PdfDocumentInfo, list[PageTextRecord]]:
    """Validate *path* and extract all of its pages.

    Convenience wrapper over :func:`pagetrace.pdf_input.load_pdf` and
    :func:`extract_pages`. Limit overrides are passed through only
    when given (``None`` keeps the defaults).
    """
    kwargs: dict = {}
    if max_file_size_bytes is not None:
        kwargs["max_file_size_bytes"] = max_file_size_bytes
    if max_pages is not None:
        kwargs["max_pages"] = max_pages
    info = load_pdf(path, **kwargs)
    return info, extract_pages(info)
